package com.monteCCer.projetoatitude.model;

public class Resposta_Cidade {
    private String codigo, nome;

    public String getCodigo() {
        return codigo;
    }

    public String getNome() {
        return nome;
    }
}

package com.monteCCer.projetoatitude.model;

public class Resposta_Estado {
    private String codigo, nome, sigla;

    public String getCodigo() {
        return codigo;
    }

    public String getNome() {
        return nome;
    }

    public String getSigla() {
        return sigla;
    }
}
